﻿
namespace GROUP7_MessagingAPP
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmbIndividual_Chat = new System.Windows.Forms.ComboBox();
            this.rdbGroupChat = new System.Windows.Forms.RadioButton();
            this.rdbIndividual_Chat = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lb_Chat = new System.Windows.Forms.ListBox();
            this.txtChat = new System.Windows.Forms.TextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.btnDisconnect = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPort_Number = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtIP_Address = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Gill Sans MT", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(325, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(348, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "Group 7 Messaging App";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmbIndividual_Chat);
            this.groupBox1.Controls.Add(this.rdbGroupChat);
            this.groupBox1.Controls.Add(this.rdbIndividual_Chat);
            this.groupBox1.Location = new System.Drawing.Point(7, 257);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(339, 115);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Messaging Type";
            // 
            // cmbIndividual_Chat
            // 
            this.cmbIndividual_Chat.FormattingEnabled = true;
            this.cmbIndividual_Chat.Location = new System.Drawing.Point(181, 63);
            this.cmbIndividual_Chat.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbIndividual_Chat.Name = "cmbIndividual_Chat";
            this.cmbIndividual_Chat.Size = new System.Drawing.Size(138, 28);
            this.cmbIndividual_Chat.TabIndex = 4;
            this.cmbIndividual_Chat.SelectedIndexChanged += new System.EventHandler(this.cmbIndividual_Chat_SelectedIndexChanged);
            // 
            // rdbGroupChat
            // 
            this.rdbGroupChat.AutoSize = true;
            this.rdbGroupChat.Location = new System.Drawing.Point(19, 29);
            this.rdbGroupChat.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rdbGroupChat.Name = "rdbGroupChat";
            this.rdbGroupChat.Size = new System.Drawing.Size(105, 24);
            this.rdbGroupChat.TabIndex = 2;
            this.rdbGroupChat.TabStop = true;
            this.rdbGroupChat.Text = "Group Chat";
            this.rdbGroupChat.UseVisualStyleBackColor = true;
            // 
            // rdbIndividual_Chat
            // 
            this.rdbIndividual_Chat.AutoSize = true;
            this.rdbIndividual_Chat.Location = new System.Drawing.Point(181, 29);
            this.rdbIndividual_Chat.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rdbIndividual_Chat.Name = "rdbIndividual_Chat";
            this.rdbIndividual_Chat.Size = new System.Drawing.Size(129, 24);
            this.rdbIndividual_Chat.TabIndex = 3;
            this.rdbIndividual_Chat.TabStop = true;
            this.rdbIndividual_Chat.Text = "Individual Chat";
            this.rdbIndividual_Chat.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lb_Chat);
            this.groupBox2.Controls.Add(this.txtChat);
            this.groupBox2.Controls.Add(this.btnSend);
            this.groupBox2.Controls.Add(this.btnDisconnect);
            this.groupBox2.Location = new System.Drawing.Point(410, 115);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Size = new System.Drawing.Size(627, 500);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Messaging ";
            // 
            // lb_Chat
            // 
            this.lb_Chat.FormattingEnabled = true;
            this.lb_Chat.ItemHeight = 20;
            this.lb_Chat.Location = new System.Drawing.Point(7, 29);
            this.lb_Chat.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.lb_Chat.Name = "lb_Chat";
            this.lb_Chat.Size = new System.Drawing.Size(613, 364);
            this.lb_Chat.TabIndex = 4;
            this.lb_Chat.SelectedIndexChanged += new System.EventHandler(this.lb_Chat_SelectedIndexChanged);
            // 
            // txtChat
            // 
            this.txtChat.Location = new System.Drawing.Point(7, 425);
            this.txtChat.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtChat.Name = "txtChat";
            this.txtChat.Size = new System.Drawing.Size(410, 27);
            this.txtChat.TabIndex = 3;
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(424, 411);
            this.btnSend.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(95, 56);
            this.btnSend.TabIndex = 2;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // btnDisconnect
            // 
            this.btnDisconnect.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnDisconnect.Location = new System.Drawing.Point(526, 411);
            this.btnDisconnect.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnDisconnect.Name = "btnDisconnect";
            this.btnDisconnect.Size = new System.Drawing.Size(95, 56);
            this.btnDisconnect.TabIndex = 1;
            this.btnDisconnect.Text = "Disconnect";
            this.btnDisconnect.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnConnect);
            this.groupBox3.Controls.Add(this.groupBox1);
            this.groupBox3.Controls.Add(this.txtUsername);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.txtPort_Number);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.txtIP_Address);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Location = new System.Drawing.Point(24, 115);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox3.Size = new System.Drawing.Size(355, 500);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Connection";
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(74, 416);
            this.btnConnect.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(182, 45);
            this.btnConnect.TabIndex = 4;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // txtUsername
            // 
            this.txtUsername.Location = new System.Drawing.Point(103, 148);
            this.txtUsername.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(204, 27);
            this.txtUsername.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 152);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "UserName:";
            // 
            // txtPort_Number
            // 
            this.txtPort_Number.Location = new System.Drawing.Point(103, 97);
            this.txtPort_Number.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtPort_Number.Name = "txtPort_Number";
            this.txtPort_Number.Size = new System.Drawing.Size(204, 27);
            this.txtPort_Number.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Port Number:";
            // 
            // txtIP_Address
            // 
            this.txtIP_Address.Location = new System.Drawing.Point(105, 47);
            this.txtIP_Address.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtIP_Address.Name = "txtIP_Address";
            this.txtIP_Address.Size = new System.Drawing.Size(202, 27);
            this.txtIP_Address.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "IP address:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = global::GROUP7_MessagingAPP.Properties.Resources.Image;
            this.ClientSize = new System.Drawing.Size(1061, 652);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbIndividual_Chat;
        private System.Windows.Forms.RadioButton rdbGroupChat;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtChat;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.Button btnDisconnect;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPort_Number;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtIP_Address;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbIndividual_Chat;
        private System.Windows.Forms.ListBox lb_Chat;
    }
}

