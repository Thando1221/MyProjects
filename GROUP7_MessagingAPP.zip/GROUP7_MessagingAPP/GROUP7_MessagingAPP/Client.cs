﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Sockets;
using Newtonsoft.Json;
using System.Threading;
using System.Threading.Tasks;

namespace GROUP7_MessagingAPP
{
    class Client
    {
        public string username;
        private TcpClient tcpClient; //allow them to communicate with server


        public Client(string username, string IPaddress, int port)
        {
            setUsername(username);
            openConnection(IPaddress, port);
        }

        public void ReceiveMessages()
        {

            while (true) // Run indefinitely
            {
                ReceiveMessagesFromServer();
            }
        }

        public Message receiveMessageFromServer()
        {
            NetworkStream clientStream = tcpClient.GetStream();
            byte[] messagebyte = new byte[4096];
            int bytesRead;
            bytesRead = clientStream.Read(messagebyte, 0, 4096);
            string jsonMessage = Encoding.UTF8.GetString(messagebyte, 0, bytesRead);
            Console.WriteLine(jsonMessage);
            Message receivedMessage = JsonConvert.DeserializeObject<Message>(jsonMessage);
            Console.WriteLine(receivedMessage.sender);
            return receivedMessage;
        }


        private void setUsername(string username)
        {
            this.username = username;
        }

        public void sendMessage(Message message)
        {
            //write to message object to the network stream
            NetworkStream stream = tcpClient.GetStream();
            string jsonMessage = JsonConvert.SerializeObject(message);
            byte[] data = Encoding.UTF8.GetBytes(jsonMessage);
            stream.Write(data, 0, data.Length);
            stream.Flush();
            Console.WriteLine("Message sent to server");
        }

        //no needed like this. The UI
        public List<string> getListOfUsernames()
        {
            Message message = new Message();
            message.sender = this.username;
            message.askingForClientsListUsername = true;
            sendMessage(message);
            message = receiveMessageFromServer();
            return message.clientsListUsernames;
        }

        public List<Message> ReceiveMessagesFromServer()
        {
            NetworkStream clientStream = tcpClient.GetStream();
            StringBuilder stringBuilder = new StringBuilder();
            List<Message> receivedMessages = new List<Message>();

            // Read data until a complete JSON message is received

            byte[] buffer = new byte[4096];
            int bytesRead = clientStream.Read(buffer, 0, buffer.Length);
            if (bytesRead == 0)
            {
                // Connection closed by the server or no data available
                //throw new Exception("Connection closed by the server or no data available.");
                return receivedMessages;
            }

            // Append the received data to the string builder
            stringBuilder.Append(Encoding.UTF8.GetString(buffer, 0, bytesRead));

            // Check if we have received a complete JSON message
            string jsonMessages = stringBuilder.ToString();
            if (jsonMessages.Contains("}"))
            {
                // Split the concatenated JSON messages
                string[] jsons = jsonMessages.Split(new[] { "}" }, StringSplitOptions.RemoveEmptyEntries);

                foreach (string json in jsons)
                {
                    string jsonMessage = json + "}";
                    Console.WriteLine(jsonMessage);
                    Message receivedMessage = JsonConvert.DeserializeObject<Message>(jsonMessage);
                    receivedMessages.Add(receivedMessage);
                }

                // Clear the string builder for the next iteration
                stringBuilder.Clear();
            }

            return receivedMessages; // Return the list of received messages
        }


        public void openConnection(string IPaddress, int port)
        {
            Message message = new Message(true, this.username);
            this.tcpClient = new TcpClient(IPaddress, port);
            sendMessage(message);
            Console.WriteLine("Connected to server.");
        }
        public void closeConnection()
        {
            this.tcpClient.Close();
        }

    }
}
