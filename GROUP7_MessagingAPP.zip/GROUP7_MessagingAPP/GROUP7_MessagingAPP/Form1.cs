﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GROUP7_MessagingAPP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Initialization and Declaring of Variables
        private bool connect_Status=false;
        Client client;
        private void Form1_Load(object sender, EventArgs e)
        {


            //Instructions to use the App
            lb_Chat.Items.Add("  ****** INSTRUCTION TO USE APP ****** ");
            lb_Chat.Items.Add("1.Enter the IP Adress of the server");
            lb_Chat.Items.Add("2.Enter the port number of the server(Default:1234)");
            lb_Chat.Items.Add("3.Select if you want to chat to Individual or Group");
            lb_Chat.Items.Add("4.Enter your message and Click Send");
            lb_Chat.Items.Add("5.Click Disconnect to leave the Chat");

            //hide send and disconnect buttons when user is not connected to the server 
            if (connect_Status == false)
            {
                btnSend.Visible=false;
                btnDisconnect.Visible=false;
                txtChat.Visible = false;
            }
            else 
            {
                btnSend.Visible = true;
                btnDisconnect.Visible = true;
                txtChat.Visible = true;
            }
            //Port Number
            txtPort_Number.Text = "8888";
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            //clear the chats listbox 
            lb_Chat.Items.Clear();
            client = new Client(txtUsername.Text, txtIP_Address.Text, int.Parse(txtPort_Number.Text));
            //if no error 
            btnSend.Visible = true;
            btnDisconnect.Visible = true;
            txtChat.Visible = true;


            //get messages from server continously
            Thread thread = new Thread(() =>
            {
                // Send message and receive response in a separate thread
                Message message = new Message();
                message.sender = txtUsername.Text;
                message.askingForClientsListUsername = true;
                client.sendMessage(message);

                while (true)
                {
                    // Receive messages from the server
                    List<Message> messages = client.ReceiveMessagesFromServer();

                    // Display received messages on UI
                    DisplayMessagesOnUI(messages);

                    Thread.Sleep(5000);
                }
                  
            });

            // Start the thread
            thread.Start();

        }

        public void DisplayMessagesOnUI(List<Message> messages)
        {
            foreach (Message message in messages)
            {
                if (message.askingForClientsListUsername)
                {
                    // Put usernames in ddl
                    ClearComboBox();
                    foreach (string username in message.clientsListUsernames)
                    {
                        // Invoke UI updates to avoid cross-thread operation exception
                        cmbIndividual_Chat.Invoke((MethodInvoker)(() =>
                        {
                            cmbIndividual_Chat.Items.Add(username);
                        }));
                    }
                }
                if (message.isPrivateMessage)
                {
                    // Show message dialog 
                    string title = "Private message from " + message.sender;
                    string content = message.content;
                    // Invoke UI updates to show the message box on the UI thread
                    Invoke((MethodInvoker)(() =>
                    {
                        MessageBox.Show(this, content, title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }));
                }
                if (message.isPublicMessage)
                {
                    // Add to list box
                    string listItem = $"[{DateTime.Now.ToString("HH:mm:ss")}] {message.sender}: {message.content}";
                    // Invoke UI updates to add the item to the ListBox on the UI thread
                    lb_Chat.Invoke((MethodInvoker)(() =>
                    {
                        lb_Chat.Items.Add(listItem);
                    }));
                }
            }
        }
        public void ClearComboBox()
        {
            // Use Invoke to access UI controls safely from a non-UI thread
            cmbIndividual_Chat.Invoke((MethodInvoker)(() =>
            {
                cmbIndividual_Chat.Items.Clear();
            }));
        }

        private void cmbIndividual_Chat_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lb_Chat_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            //send message to server
            //check if group or indivial options
            if (!rdbGroupChat.Checked && !rdbIndividual_Chat.Checked)
            {
                MessageBox.Show("Please select group or indivisual message option");
                return;
            }
            else if (rdbIndividual_Chat.Checked &&  cmbIndividual_Chat.SelectedIndex ==-1 )
            {
                MessageBox.Show("Please select an indivisual to send the message. ");
                return;
            }
            else if(txtChat.Text == "")
            {
                MessageBox.Show("Please enter a message to send");
                return;
            }
            Message message = new Message();
            message.isPrivateMessage = rdbIndividual_Chat.Checked;
            message.isPublicMessage = rdbGroupChat.Checked;
            message.sender = client.username;
            if (rdbIndividual_Chat.Checked)
            {
                message.recipient = cmbIndividual_Chat.SelectedItem.ToString();
            }
            message.content = txtChat.Text;
            client.sendMessage(message);


        }
    }
}
