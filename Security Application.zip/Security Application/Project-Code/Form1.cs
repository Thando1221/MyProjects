﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Code
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int startPoint = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            startPoint += 1;
            guna2ProgressBar1.Value = startPoint;
            lblPercentage.Text = guna2ProgressBar1.Value.ToString();

            if (guna2ProgressBar1.Value >= 30 && guna2ProgressBar1.Value <= 70)
            {
                startPoint += 3;
                lblPercentage.Text = guna2ProgressBar1.Value.ToString();
            }
            else if (guna2ProgressBar1.Value == 80)
            {
                startPoint += 15;
                lblPercentage.Text = guna2ProgressBar1.Value.ToString();
            }
            else if (guna2ProgressBar1.Value == 100)
            {
                guna2ProgressBar1.Value = 0;
                timer1.Stop();
                this.Hide();

                SignIn signIn = new SignIn();
                signIn.Show();
            }

        }
    }
}
