﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Code
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void pbProfileImage_Click(object sender, EventArgs e)
        {
            Profile profile = new Profile();
            profile.Show();
        }

        private void lblClose_Click(object sender, EventArgs e)
        {
            //close the application
            Application.Exit();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            PendingAppointments pendingAppointment = new PendingAppointments();
            pendingAppointment.Show();
            this.Hide();
        }
    }
}
