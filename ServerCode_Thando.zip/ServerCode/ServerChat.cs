﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace ServerCode
{
    class ServerChat
    {
        private TcpListener tcpListener;
        private IPAddress ipAddress;
        private int port;
        public Dictionary<string, TcpClient> clients = new Dictionary<string, TcpClient>();

        public ServerChat(string ipAddress, int port)
        {
            this.ipAddress = IPAddress.Parse(ipAddress);
            this.port = port;
            tcpListener = new TcpListener(this.ipAddress, this.port);
            tcpListener.Start();
            Console.WriteLine("Server is running...");

            while (true)
            {
                // Accept new client connections and add them to the list
                if (tcpListener.Pending())
                {
                    TcpClient newClient = tcpListener.AcceptTcpClient();
                    Console.WriteLine("New client connected.");
                    handleNewClient(newClient);
                }
                HandleExistingClientsCommunications();
            }
        }
        public Message receiveMessageFromClient(TcpClient tcpClient)
        {
            NetworkStream clientStream = tcpClient.GetStream();
            byte[] messagebyte = new byte[4096];
            int bytesRead;
            bytesRead = clientStream.Read(messagebyte, 0, 4096);
            string jsonMessage = Encoding.UTF8.GetString(messagebyte, 0, bytesRead);
            if (bytesRead != 0)
            {
                try
                {
                    int indexOfEnd = jsonMessage.IndexOf("}");
                    jsonMessage = jsonMessage.Substring(0, indexOfEnd + 1);

                    Message receivedMessage = JsonConvert.DeserializeObject<Message>(jsonMessage);
                    return receivedMessage;
                }
                catch (JsonException ex)
                {
                    //Handle JSON parsing errors
                    Console.WriteLine("Error deserializing message: " + ex.Message);
                    //Throw new Exception("Error deserializing message: " + );
                }
            }


            return null;
        }

        private void handleNewClient(TcpClient newClient)
        {
            Message receivedMessage = receiveMessageFromClient(newClient);

            if (receivedMessage != null)
            {
                clients.Add(receivedMessage.sender, newClient);
                Console.WriteLine("Accepted new client with username " + receivedMessage.sender);
            }
            else
            {
                // Handle the case where no message was received from the client
                Console.WriteLine("waiting for client to send user info.");
            }
        }
        private void HandleExistingClientsCommunications()
        {
            foreach (var kvp in clients)
            {
                //clients disconnected maybe send a message to everyone so we know who is there
                if (!kvp.Value.Connected)
                {
                    // Remove disconnected clients from the dictionary
                    clients.Remove(kvp.Key);
                    Console.WriteLine("Client disconnected: " + kvp.Key);
                }
                else if (kvp.Value.GetStream().DataAvailable)//error prone -  property might be true because there's some data in the stream, but it might not be the complete message.
                {
                    Message receivedMessage = receiveMessageFromClient(kvp.Value);
                    if (receivedMessage != null)
                    {
                        sendMessage(receivedMessage);
                    }

                }
            }
        }

        public void sendMessageToClient(Message message, TcpClient tcpClient)
        {
            try
            {
                // Write to message object to the network stream
                NetworkStream stream = tcpClient.GetStream();
                string jsonMessage = JsonConvert.SerializeObject(message);
                byte[] data = Encoding.UTF8.GetBytes(jsonMessage);
                stream.Write(data, 0, data.Length);
                stream.Flush();
            }
            catch (Exception ex)
            {
                // Handle other exceptions
                Console.WriteLine("An error occurred: " + ex.Message);
            }
        }
        private void sendMessage(Message message)
        {

            if (message.isPublicMessage)
            {
                foreach (var kvp in clients)
                {
                    //every client will receive it
                    if (true)
                    {
                        // Get the network stream for reading and writing
                        sendMessageToClient(message, kvp.Value);

                        Console.WriteLine("Public message sent to all clients.");
                    }

                }
            }

            else if (message.isPrivateMessage)
            {
                if (clients.ContainsKey(message.recipient))
                {
                    TcpClient recipientClient = clients[message.recipient];
                    sendMessageToClient(message, recipientClient);
                    Console.WriteLine("Message sent to specific recipient client with username " + message.recipient);
                }
                //handle if client left
                //maybe message should have lost client flag. 
            }

            else if (message.askingForClientsListUsername)
            {
                foreach (var kvp in clients)
                {
                    message.clientsListUsernames.Add(kvp.Key);
                    Console.WriteLine(kvp.Key);
                }
                TcpClient recipientClient = clients[message.sender];
                sendMessageToClient(message, recipientClient);
                Console.WriteLine("Message sent to sender. they have the list of usernames");
                
            }


        }
    }
}
