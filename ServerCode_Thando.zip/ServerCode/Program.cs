﻿using System;
using System.Threading;

namespace ServerCode
{
    class Program
    {
        static void Main(string[] args)
        {
            ServerChat serverChat = new ServerChat("143.160.105.54", 8888);
        }
    }
}
