﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ServerCode
{
    class Message
    {
        public string sender;
        public string recipient;
        public string content;
        public bool isPublicMessage;
        public bool isPrivateMessage;
        public bool isNewClient;
        public bool askingForClientsListUsername;
        public List<string> clientsListUsernames = new List<string>();

        public Message(bool isNewClient, string sender, string recipient, string content, bool isPublicMessage)
        {
            this.sender = sender;
            this.recipient = recipient;
            this.content = content;
            this.isPublicMessage = isPublicMessage;
            this.isNewClient = isNewClient;
        }
        //when the client wants to connect the server for the first time
        public Message(bool isNewClient, string sender)
        {
            this.sender = sender;
            this.isNewClient = isNewClient;
        }
        
        public Message()
        {
        }
    }
}
